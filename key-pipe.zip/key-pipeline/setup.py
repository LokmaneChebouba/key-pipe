from distutils.core import setup

setup(
    name="pipeline for hcc method",
    version="0.0.1",
    author="Maxime, Vincent, Arnaud, Lokmane, Carito, Nathalie",
    author_email="lchebouba@gmail.com",
    description="pipe package",
    url="https://github.com/pypa/sampleproject",
    include_package_data=True,
    packages=["supmat"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
